PYTHON_EXTENSIONS_PATHS = [
    os.path.join('C:/Users/s3459/AppData/Local/Programs/Python/Python310/Lib/site-packages/cv2', 'python-3.10')
] + PYTHON_EXTENSIONS_PATHS
